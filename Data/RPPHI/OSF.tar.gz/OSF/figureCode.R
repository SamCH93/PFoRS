####  Code for producing figures in:                         ###
####                                                         ###
####                                                         ###
####   Cova, F. et al.,                                      ###
####           Estimating the Reproducibility of             ###
####            Experimental Philosophy                      ###
####                                                         ###
####   Contact: phillips01@g.harvard.edu                     ###


#### directory and packages #####

setwd("C:/Users/jonat/Downloads/osfstorage-archive") ## set wokring directory to OSF repository download (wherever that is)

library(stringr)
library(tidyverse)
library(wesanderson)

jphilPalette <- c(wes_palette("BottleRocket2",5)[2],"white",wes_palette("BottleRocket2",5)[4],wes_palette("BottleRocket2",5)[1])
blackGreyPalette <- c("#2C3539", "#999999")

data <- read.csv("XPhiReplicability_CompleteData.csv",stringsAsFactors = F)

data$ReplicationR95CI_min <- str_extract(data$ReplicationR95CI, "\\[.*,")
data$ReplicationR95CI_min <- gsub("\\[","",data$ReplicationR95CI_min)
data$ReplicationR95CI_min <- gsub("\\,","",data$ReplicationR95CI_min)
data$ReplicationR95CI_min <- as.numeric(data$ReplicationR95CI_min)

data$ReplicationR95CI_max <- str_extract(data$ReplicationR95CI, "\\,.*]")
data$ReplicationR95CI_max <- gsub("\\]","",data$ReplicationR95CI_max)
data$ReplicationR95CI_max <- gsub("\\,","",data$ReplicationR95CI_max)
data$ReplicationR95CI_max <- gsub("\\,","",data$ReplicationR95CI_max)
data$ReplicationR95CI_max <- as.numeric(data$ReplicationR95CI_max)

data$PAPER_ID <- factor(data$PAPER_ID)

data$CATEGORY[is.na(data$CATEGORY)] <- "Observatonal Data"
data$CATEGORY <- factor(data$CATEGORY)
data$CATEGORY <- factor(c("Content Based","Context Based","Demographic Effect","Observational Data")[data$CATEGORY])

data.graph <- data %>% 
              select(PAPER_ID,ReplicationRES,CATEGORY,ReplicationRES,ReplicationR95CI_min,ReplicationR95CI_max,OriginalRES,EffectTYPE,YEAR) %>%
              filter(!is.na(ReplicationRES))

data.graph$CATEGORY <- factor(data.graph$CATEGORY, levels=c("Content Based","Observational Data","Context Based","Demographic Effect"))

data.graph$EffectTYPE <- factor(data.graph$EffectTYPE)
data.graph$EffectTYPE <- factor(c("Null Effect","Positive Effect")[data.graph$EffectTYPE])
data.graph$EffectTYPE <- factor(data.graph$EffectTYPE, levels = c("Null Effect","Positive Effect"))


## Figure 1 ####

order <- data.graph$PAPER_ID[order(data.graph$EffectTYPE,data.graph$ReplicationRES)]

data.graph$PAPER_ID <- factor(data.graph$PAPER_ID, levels=order)

fig1 <- ggplot(data.graph, aes(x=PAPER_ID, y=ReplicationRES,
                fill=CATEGORY, shape=CATEGORY)) + 
                ggtitle("Replicated and Original Effect Sizes by Study") +
                geom_hline(yintercept=0,lty=4) +
                geom_linerange(aes(ymin=ReplicationR95CI_min,ymax=ReplicationR95CI_max),lty=3,alpha=.5) + 
                geom_point(aes(y=OriginalRES),shape=3, colour="Red",size=2)+
                geom_point(size=4) +
                coord_cartesian(ylim=c(-0.25,1)) +
                annotate("text", x = 1.5, y = .75, label = "Null Effect Replications", size=6) +
                geom_vline(xintercept=2.5,lty=2) +
                xlab("") + 
                ylab("Effect Size r") +
                annotate("text", x = 8.45, y = .73, label = "Original Effect",size=5.5) +
                annotate("text", x = 8.45, y = .57, label = "+",size=5,color="Red")+
                scale_fill_manual(name="Study Type:", values=c(jphilPalette,"Red"), 
                                    labels=c("Content Based","Observational Data","Context Based","Demographic Effect"),drop=TRUE) +
                scale_shape_manual(name="Study Type:", values = c(21:24), 
                                   labels=c("Content Based","Observational Data","Context Based","Demographic Effect"),drop=TRUE) +
                coord_flip() +
                theme_bw() +
                theme(strip.text = element_text(size=14),
                      axis.text = element_text(size=14),
                      plot.title = element_text(size=18, face="bold",hjust=.5),
                      axis.title.x = element_text(size=16, vjust=-0.2),
                      axis.title.y = element_text(size=16, vjust=0.35),
                      legend.title = element_text(size=16),
                      legend.text = element_text(size=16),
                      legend.position = c(.8,.3),
                      panel.grid = element_blank())

#fig1


## Figure 2 ####
data.graph2 <- data.graph %>% 
              gather(resTYPE,RES,c("ReplicationRES","OriginalRES"))

data.graph2$resTYPE <- factor(data.graph2$resTYPE)
data.graph2$resTYPE <- factor(c("Original Effects","Replicated Effects"))


fig2a <- ggplot(data.graph2[data.graph2$EffectTYPE!="Null Effect" & data.graph2$resTYPE=="Original Effects",], aes(RES,fill=CATEGORY)) +
                   geom_dotplot(dotsize = .75,stackgroups = TRUE, binpositions= "all") +
                   #facet_wrap(~resTYPE, ncol = 1) +
                   geom_vline(xintercept=0,lty=4) +
                   ggtitle("Original Effect Sizes") +
                   ylab("Number of studies") +
                   xlab("Effect Size r") +
                   #scale_fill_manual(values=jphilPalette) +
                   #scale_fill_manual(name="",values=gray.colors(2, start = 0.3, end = 0.9, gamma = 2.2)) +
                   scale_fill_manual(name="Study Type:", values=c(jphilPalette,"Red"), 
                    labels=c("Content Based","Observational Data","Context Based","Demographic Effect"),drop=TRUE) +
                   coord_cartesian(xlim=c(-0.072,.85)) +
                   theme_bw() +
                   theme(strip.text = element_text(size=14),
                          axis.text = element_text(size=14),
                          axis.text.y = element_blank(),
                          axis.title.x = element_text(size=16, vjust=-0.2),
                          axis.title.y = element_text(size=16, vjust=0.35),
                          legend.title = element_text(size=16),
                          legend.text = element_text(size=16),
                          plot.title = element_text(size=18, face="bold",hjust=.5),
                          #legend.position = "left",
                          legend.position = c(.85,.7),
                          panel.grid = element_blank())
#fig2a

fig2b <- ggplot(data.graph, aes(ReplicationRES,fill=CATEGORY)) +
  geom_dotplot(dotsize = .75) +
  facet_wrap(~CATEGORY, ncol = 1) +
  geom_vline(xintercept=0,lty=4) +
  #scale_fill_manual(name="",values=blackGreyPalette) +
  ggtitle("Replicated Effect Sizes by Study Type") +
  ylab("Number of Studies") +
  xlab("Effect Size r") +
  coord_cartesian(xlim=c(-0.072,.85)) +
  scale_fill_manual(name="Study Type:", values=c(jphilPalette,"Red"), 
                    labels=c("Content Based","Observational Data","Context Based","Demographic Effect"),drop=TRUE) +
  theme_bw() +
  theme(strip.text = element_text(size=14),
        axis.text = element_text(size=14),
        axis.text.y = element_blank(),
        plot.title = element_text(size=18, face="bold",hjust=.5),
        axis.title.x = element_text(size=16, vjust=-0.2),
        axis.title.y = element_text(size=16, vjust=0.35),
        legend.title = element_text(size=16),
        legend.text = element_text(size=16),
        legend.position = "none",
        #legend.position = c(.8,.9),
        panel.grid = element_blank())

#fig2b

## Figure 3 ####

data.graph3 <- data.graph %>% select(PAPER_ID,ReplicationRES,OriginalRES,YEAR) %>%
                              gather(type,RES,c("OriginalRES","ReplicationRES"))

data.graph3$type <- factor(data.graph3$type)
data.graph3$type <- factor(c("Original Effect","Replicated Effect")[data.graph3$type])
#data.graph3$type <- factor(data.graph3$type,levels=c("Replicated Effect","Original Effect"))

fig3 <- ggplot(data.graph3, aes(x=YEAR, y=RES,fill=type,shape=type)) + 
  ggtitle("Replicated and Original Effect Sizes by Year") +
  geom_hline(yintercept=0,lty=4) +
  #geom_linerange(aes(ymin=ReplicationR95CI_min,ymax=ReplicationR95CI_max),lty=3,alpha=.5) + 
  #geom_point(aes(y=OriginalRES),shape=3, colour="Red",size=2)+
  geom_point(size=4,alpha=.75,position=position_jitterdodge()) +
  geom_smooth(aes(color=type),method="lm",alpha=.65,linetype=2,se=FALSE) +
  coord_cartesian(ylim=c(-0.25,1),xlim=c(2003,2016),expand=T) +
  #annotate("text", x = 1.5, y = .75, label = "Null Effect Replications", size=6) +
  #geom_vline(xintercept=2.5,lty=2) +
  xlab("Publication Year") + 
  ylab("Effect Size r") +
  #annotate("text", x = 8.45, y = .725, label = "Original Effect",size=5.5) +
  #annotate("text", x = 8.45, y = .57, label = "+",size=5,color="Red")+
  scale_fill_manual(name="Effect Type:", values=blackGreyPalette) +
  scale_color_manual(name="Effect Type:", values=blackGreyPalette) +
  scale_shape_manual(name="Effect Type:",values=c(1,21)) +
  theme_bw() +
  theme(strip.text = element_text(size=14),
        axis.text = element_text(size=14),
        plot.title = element_text(size=18, face="bold",hjust=.5),
        axis.title.x = element_text(size=16, vjust=-0.2),
        axis.title.y = element_text(size=16, vjust=0.35),
        legend.title = element_text(size=16),
        legend.text = element_text(size=16),
        legend.position = c(.85,.9),
        panel.grid = element_blank())

#fig3


